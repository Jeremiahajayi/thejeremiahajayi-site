<?php
/**
 * Not found.
 */
get_header();
?>
<section class="simple">
<div class="wrap" style="max-width:880px">
<p class="eyebrow">Page not found</p>
<h1>This article isn’t here<span class="dot">.</span></h1>
<p style="font-size:18px">It may have moved. <a href="<?php echo esc_url( home_url( '/' ) ); ?>">See all writing →</a></p>
</div>
</section>
<?php
get_footer();
