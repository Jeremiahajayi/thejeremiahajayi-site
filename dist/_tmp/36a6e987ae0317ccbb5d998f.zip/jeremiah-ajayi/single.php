<?php
/**
 * A single article.
 */
get_header();

while ( have_posts() ) :
	the_post();
	?>
<article id="article">
<header class="p-head">
<div class="wrap">
<p class="crumb"><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Blog</a> <span aria-hidden="true">/</span> Article</p>
<h1 class="p-title"><?php the_title(); ?></h1>
<p class="p-meta"><b>Jeremiah Ajayi</b> · <time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date( 'j F Y' ) ); ?></time> · <?php echo esc_html( ja_minutes() ); ?> min read</p>
</div>
</header>
<?php if ( has_post_thumbnail() ) : ?>
<div class="p-cover"><?php the_post_thumbnail( 'large', array( 'alt' => '', 'loading' => 'eager', 'fetchpriority' => 'high' ) ); ?></div>
<?php endif; ?>
<div class="p-body">
<div class="post-body">
<?php the_content(); ?>
</div>
</div>
</article>
	<?php
endwhile;

get_footer();
