<?php
/**
 * A plain page.
 */
get_header();
while ( have_posts() ) :
	the_post();
	?>
<section class="simple">
<div class="wrap" style="max-width:880px">
<h1><?php the_title(); ?></h1>
<div class="post-body" style="margin:0"><?php the_content(); ?></div>
</div>
</section>
	<?php
endwhile;
get_footer();
