<!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<?php if ( ! is_user_logged_in() ) : ?><noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-TQCD7V7B" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript><?php endif; ?>
<a class="skip" href="#main">Skip to content</a>
<header class="site-h">
<div class="wrap">
<a class="brand" href="<?php echo esc_url( JA_SITE . '/' ); ?>"><span class="ct-mark" aria-hidden="true">JA</span>Jeremiah Ajayi</a>
<button class="menu-t" type="button" aria-expanded="false" aria-controls="ja-nav">Menu <i aria-hidden="true">≡</i></button>
<nav id="ja-nav" class="nav" aria-label="Primary"><?php ja_nav( 'writing' ); ?></nav>
</div>
</header>
<main id="main">
