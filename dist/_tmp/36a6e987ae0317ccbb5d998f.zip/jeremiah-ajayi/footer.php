</main>
<section class="endband" id="end" aria-labelledby="end-t">
<div class="wrap">
<h2 id="end-t" class="sg">Need help with your marketing<span class="dot">?</span></h2>
<p>I help B2B SaaS and technology companies with positioning, product launches, and content that brings in customers.</p>
<div class="ctas">
<a class="btn btn-o" href="<?php echo esc_url( JA_CALENDLY ); ?>">Book a call ↗</a>
<a class="btn btn-l" href="<?php echo esc_url( JA_SITE . '/what-id-do/' ); ?>">Get the What I’d Do newsletter →</a>
</div>
<footer class="k-foot">
<a class="k-brand" href="<?php echo esc_url( JA_SITE . '/' ); ?>"><span class="ct-mark" aria-hidden="true">JA</span>Jeremiah Ajayi</a>
<span class="k-fnav">
<a href="<?php echo esc_url( JA_SITE . '/services/positioning-messaging/' ); ?>">Positioning</a>
<a href="<?php echo esc_url( JA_SITE . '/services/product-launch-gtm/' ); ?>">Launches &amp; GTM</a>
<a href="<?php echo esc_url( JA_SITE . '/services/content-growth/' ); ?>">Content &amp; storytelling</a>
<a href="<?php echo esc_url( JA_SITE . '/work/' ); ?>">Work</a>
<a href="<?php echo esc_url( JA_SITE . '/what-id-do/' ); ?>">What I’d Do</a>
<a href="<?php echo esc_url( JA_SITE . '/writing/' ); ?>">Writing</a>
<a href="<?php echo esc_url( home_url( '/' ) ); ?>">Blog</a>
<a href="<?php echo esc_url( JA_SITE . '/about/' ); ?>">About</a>
<a href="<?php echo esc_url( JA_SITE . '/empowerq/' ); ?>">EmpowerQ</a>
<a href="<?php echo esc_url( JA_SITE . '/contact/' ); ?>">Contact</a>
<a href="https://www.linkedin.com/in/jeremiah-ajayi/">LinkedIn</a>
<span>Lagos 🇳🇬 · © <?php echo esc_html( gmdate( 'Y' ) ); ?></span>
</span>
</footer>
</div>
</section>
<?php wp_footer(); ?>
</body>
</html>
