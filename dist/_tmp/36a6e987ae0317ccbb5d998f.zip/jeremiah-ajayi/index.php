<?php
/**
 * Writing: the blog home, archives and search results.
 */
get_header();

$is_home = is_home() && ! is_paged();
if ( is_home() ) {
	$heading = 'Blog';
	$lede    = 'Articles on marketing, product launches, content and AI search.';
} elseif ( is_search() ) {
	$heading = 'Search';
	$lede    = sprintf( 'Results for “%s”', get_search_query() );
} else {
	$heading = wp_strip_all_tags( get_the_archive_title() );
	$lede    = wp_strip_all_tags( get_the_archive_description() );
}
?>
<section class="b-hero" id="top">
<div class="wrap">
<p class="eyebrow">By Jeremiah Ajayi</p>
<h1 class="b-h1"><?php echo esc_html( $heading ); ?><span class="dot">.</span></h1>
<?php if ( $lede ) : ?><p class="b-lede"><?php echo esc_html( $lede ); ?></p><?php endif; ?>
</div>
</section>

<section class="b-list" id="posts" aria-label="Articles">
<div class="wrap">
<?php if ( have_posts() ) : ?>
<div class="grid">
<?php
$i = 0;
while ( have_posts() ) :
	the_post();
	$feat = $is_home && 0 === $i;
	$i++;
	?>
<a class="card<?php echo $feat ? ' feat' : ''; ?>" href="<?php the_permalink(); ?>">
<div class="card-img"><?php if ( has_post_thumbnail() ) { the_post_thumbnail( $feat ? 'large' : 'medium_large', array( 'alt' => '', 'loading' => $feat ? 'eager' : 'lazy' ) ); } ?></div>
<div class="card-b">
<span class="card-d"><?php echo esc_html( get_the_date( 'j F Y' ) ); ?> · <?php echo esc_html( ja_minutes() ); ?> min read</span>
<h2 class="card-t"><?php the_title(); ?></h2>
<p class="card-x"><?php echo esc_html( wp_strip_all_tags( get_the_excerpt() ) ); ?></p>
<span class="card-r">Read the article →</span>
</div>
</a>
<?php endwhile; ?>
</div>
<?php
$links = paginate_links( array( 'type' => 'array', 'prev_text' => '←', 'next_text' => '→' ) );
if ( $links ) {
	echo '<nav class="pager" aria-label="Pages">' . implode( '', $links ) . '</nav>'; // phpcs:ignore WordPress.Security.EscapeOutput
}
?>
<?php else : ?>
<p>Nothing here yet.</p>
<?php endif; ?>
</div>
</section>
<?php
get_footer();
