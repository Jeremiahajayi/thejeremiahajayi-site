<?php
/**
 * Jeremiah Ajayi theme: the Writing section of thejeremiahajayi.com.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'JA_SITE', 'https://www.thejeremiahajayi.com' );
define( 'JA_CALENDLY', 'https://calendly.com/jeremiahajayiconsultation/strategy-call-with-jeremiah-ajayi' );

add_action( 'after_setup_theme', function () {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'html5', array( 'search-form', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'align-wide' );
	add_theme_support( 'editor-styles' );
	add_editor_style( 'editor-style.css' );
	set_post_thumbnail_size( 1200, 675, true );
} );

add_action( 'wp_enqueue_scripts', function () {
	$v = wp_get_theme()->get( 'Version' );
	wp_enqueue_style( 'ja-style', get_stylesheet_uri(), array(), $v );
	// Not used on this site: keep pages light.
	wp_dequeue_style( 'classic-theme-styles' );
} );

remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
remove_action( 'wp_print_styles', 'print_emoji_styles' );

add_action( 'wp_head', function () {
	echo '<link rel="preload" href="' . esc_url( get_theme_file_uri( 'fonts/space-grotesk-latin-700-normal.woff2' ) ) . '" as="font" type="font/woff2" crossorigin>' . "\n";
	echo '<link rel="icon" href="' . esc_url( JA_SITE . '/favicon.ico' ) . '">' . "\n";
}, 1 );

/* Analytics: the same Google tag and Tag Manager container as the main site. */
add_action( 'wp_head', function () {
	if ( is_user_logged_in() ) {
		return; // Keep your own visits out of GA4.
	}
	?>
<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-537Y2VKCZ1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-537Y2VKCZ1');
</script>
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-TQCD7V7B');</script>
	<?php
}, 2 );

/* Calendly booking clicks, the same events as the main site, plus the mobile menu. */
add_action( 'wp_footer', function () {
	?>
<script>
(function () {
  var h = document.querySelector('.site-h'), t = document.querySelector('.menu-t');
  if (h && t) t.addEventListener('click', function () { var o = h.classList.toggle('open'); t.setAttribute('aria-expanded', o ? 'true' : 'false'); });
  document.addEventListener('click', function (e) {
    var a = e.target && e.target.closest ? e.target.closest('a[href*="calendly.com"]') : null;
    if (!a || typeof window.gtag !== 'function') return;
    var url = a.href, consult = url.indexOf('calendly.com/jeremiahajayiconsultation/') !== -1, sec = a.closest('[id]');
    window.gtag('event', consult ? 'book_call_click' : 'calendly_click', {
      link_url: url.split('?')[0],
      link_text: (a.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 100),
      cta_location: sec ? sec.id : 'page',
      transport_type: 'beacon'
    });
  }, true);
})();
</script>
	<?php
} );

add_filter( 'excerpt_length', function () { return 26; } );
add_filter( 'excerpt_more', function () { return '…'; } );

/** Reading time in minutes. */
function ja_minutes( $post = null ) {
	$words = str_word_count( wp_strip_all_tags( get_post_field( 'post_content', $post ) ) );
	return max( 1, (int) round( $words / 230 ) );
}

/** Main-site navigation; $current marks the active item. */
function ja_nav( $current = 'writing' ) {
	$items = array(
		'work'    => array( 'Work', JA_SITE . '/work/' ),
		'exp'     => array( 'Expertise', JA_SITE . '/services/' ),
		'wid'     => array( 'What I’d Do', JA_SITE . '/what-id-do/' ),
		'eq'      => array( 'EmpowerQ', JA_SITE . '/empowerq/' ),
		'writing' => array( 'Writing', JA_SITE . '/writing/' ),
		'about'   => array( 'About', JA_SITE . '/about/' ),
	);
	foreach ( $items as $k => $it ) {
		printf(
			'<a href="%s"%s>%s</a>',
			esc_url( $it[1] ),
			$k === $current ? ' class="on" aria-current="page"' : '',
			esc_html( $it[0] )
		);
	}
	printf( '<a class="cta" href="%s">Book a call ↗</a>', esc_url( JA_CALENDLY ) );
}
